package com.okay.validate;

public interface Filter {	
	void doFilter(int[][] data);
}
