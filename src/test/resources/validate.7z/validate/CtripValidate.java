/**
 * 
 */
package com.okay.validate;

/**
 * @author okvaward
 *
 */
public class CtripValidate {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	
	

}
