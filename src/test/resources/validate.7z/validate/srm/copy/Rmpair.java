package com.okay.validate.srm.copy;
class Rmpair
{

    Rmpair()
    {
        r1 = 0;
        r2 = 0;
        diff = 0;
    }

    int r1;
    int r2;
    int diff;
}
